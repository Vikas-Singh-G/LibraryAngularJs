libApp.controller("libSearchController",function($scope,libManage){
    $scope.libSearchEngArr=libManage.getEngbookDetails();
    $scope.libSearchRomArr=libManage.getRombookDetails();
    $scope.libSearchDevArr=libManage.getDevbookDetails();
    $scope.deleteLibEventHandler=function(libToBeDeleted)
    {
        libManage.deleteLib(libToBeDeleted);
        
    }
})