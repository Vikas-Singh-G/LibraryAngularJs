libApp.controller("libDisplayController",function($scope,libManage){
  
    $scope.engBookArr=libManage.getEngbookDetails();
    $scope.romBookArr=libManage.getRombookDetails();
    $scope.devBookArr=libManage.getDevbookDetails();
   
   


    $scope.selectedBook={};/* libManage.getEngbookDetails(); */
    $scope.showEditBook=false;
    $scope.showAddBook=false;
    $scope.editLibraryDetailsEventHandler=function(obj){
        $scope.selectedBook=obj;
        confirm("U have selected Book Id :"+ obj.bookId + " to edit");
        $scope.showEditBook=true;
    }

    $scope.showAddNewBookEventHandler=function()
    {
        $scope.showAddBook=true;
    }
    // on method is used to bind an event with an event handler
    // whenever the event gets triggered, the corresponding event handler will be executed
    $scope.$on("addNewBook",function(newBook){
        console.log(newBook);
        $scope.libArr.push(newBook);
        $scope.showAddBook=false;
    })
    $scope.$on("cancelAddNewBook",function(){
        $scope.showAddBook=false;
    })
})