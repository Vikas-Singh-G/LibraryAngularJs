libApp.service("libManage",function(){

    this.engDetails=[
            {bookId:'MS102', bookImage:"image/EngBook/MS_book.jpg", bookName:'Manufacturing Engineering',bookAuthor:'j.Paul Davim',isbnCode:'1234',bookDescp:'This book aims to provide research and review studies on manufacturing engineering. This research book can be used for final undergraduate engineering courses (for example, mechanical, manufacturing, industrial, etc) or as a subject on manufacturing at the postgraduate level. Also, this book can serve as a useful reference for academics, manufacturing researchers, mechanical manufacturing and industrial engineers, and professionals in related industries with manufacturing engineering.',price:6},
            {bookId:'CS602', bookImage:"image/EngBook/C_ShBook.png", bookName:'Advanced C#',bookAuthor:'',isbnCode:'',bookDescp:'The Roommate by Rosie Danan follows Clara, an uptight and a little bit awkward East Coaster who moves to LA to pursue her longtime crush — except when he is actually out on tour with his band, she winds up living with Josh. These two clash in personalities and they are very unlikely roommates. ',price:''},
              ];

    this.romDetails=[
            
            {bookId:'RM204', bookImage:'image/RomBook/TheR_M.jpg', bookName:'',bookAuthor:'',isbnCode:'',bookDescp:'',price:''},
            {bookId:'LB204', bookImage:'image/RomBook/LenoraBell.jpg', bookName:'',bookAuthor:'',isbnCode:'',bookDescp:'',price:''},
            {bookId:'MO204', bookImage:'image/RomBook/MapOfStar.jpg', bookName:'',bookAuthor:'',isbnCode:'',bookDescp:'',price:''},
            {bookId:'PD306', bookImage:'', bookName:'',bookAuthor:'',isbnCode:'',bookDescp:'',price:''}
                ];
    this.devDetails=[
    {bookId:'RM901', bookImage:'image/DevBook/Ramayan.jpg', bookName:'',bookAuthor:'',isbnCode:'',bookDescp:'',price:''},
    {bookId:'MB101', bookImage:'image/DevBook/Bhagavad_Gita.jpg', bookName:'',bookAuthor:'',isbnCode:'',bookDescp:'',price:''},
              ];

    this.getEngbookDetails=function()
    {
        return this.engDetails;
    }
    this.getRombookDetails=function()
    {
        return this.romDetails;
    }
    this.getDevbookDetails=function()
    {
        return this.devDetails;
    }

    
    this.addEngBook=function(lib)
    {
        this.engDetails.push(lib);
    }
    this.deleteLib=function(lib){
        var pos=this.engDetails.findIndex(item=> {
            if(item.bookId == lib.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })

        this.engDetails.splice(pos,1);
    }

})