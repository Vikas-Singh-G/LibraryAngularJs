libApp.controller("libEditController",function($scope){
    
})