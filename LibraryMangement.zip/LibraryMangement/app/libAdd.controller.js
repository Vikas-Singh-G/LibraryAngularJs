/* libApp.controller("libAddController",function($scope){
    $scope.newBook={};
    $scope.saveDetailsEventHandler=function(){
        console.log("New Book details entered",$scope.newBook);
        // send it to the parent controller
        // emit a custom event from the child controller to its parent(s)
        // emit -- takes 2 params; name of the custom events; optional data to be passed to the parent
        $scope.$emit("addNewBook",$scope.newBook);

    }
    $scope.cancelAddEmpEventHandler=function(){
        $scope.$emit("cancelAddNewBook");
        $scope.newBook={};
    }
}) */libApp.controller("libAddController",function($scope,libManage){
    $scope.saveDetailsEventHandler=function(){
        libManage.addEngBook($scope.newBook)
    }
    
})